مكتبي | MAKTABI — نسخة أولية

طريقة النشر المجاني باستخدام GitHub Pages:
1) أنشئ مستودعًا جديدًا في GitHub باسم maktabi-site.
2) اجعل المستودع Public.
3) اختر Add file ثم Upload files.
4) ارفع index.html ثم اضغط Commit changes.
5) افتح Settings ثم Pages.
6) في Build and deployment اختر Deploy from a branch.
7) اختر Branch: main والمجلد /(root)، ثم Save.
8) انتظر قليلًا، وسيظهر رابط الموقع في صفحة Pages.

ملاحظات:
- هذه نسخة ثابتة أولية؛ بعض الأقسام تجريبية ولم تُفعّل بعد.
- النماذج تعمل داخل المتصفح ولا تحفظ المعلومات على خادم.
- لا تدخل بيانات حساسة أو كلمات مرور.
- الموقع ليس تابعًا لأي جهة حكومية.
